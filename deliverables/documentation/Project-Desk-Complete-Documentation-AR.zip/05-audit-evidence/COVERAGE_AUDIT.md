# تدقيق تغطية SRS والتوثيق — Project Desk

> تاريخ اللقطة: 2026-08-12  
> نوع التدقيق: قراءة مستقلة للتنفيذ الفعلي؛ لم يُعدّل الكود أو التوثيق النهائي.  
> الغرض: منع توثيق خصائص غير منفذة، وضبط ما يجب وصفه بعبارات **Implemented / Partial / Planned / Excluded / Legacy**.  
> مصدر الحقيقة: المسارات والسياسات والطلبات والخدمات والنماذج والترحيلات والواجهات والاختبارات في المستودع، لا أسماء الملفات القديمة أو النوايا التصميمية.

## 1. الخلاصة التنفيذية

التنفيذ الحالي نظام داخلي أحادي الشركة لإدارة المشاريع والعمل، مع قوالب فواتير تصميمية فقط. النطاق الفعلي واسع ومترابط: المشاريع، المهام، العملاء، الفريق، المتطلبات وكراستها، الجدول الزمني، الاجتماعات والمحاضر، المخاطر، المشكلات، المستندات، التنبيهات، الاستيراد/التصدير، النسخ والاستعادة، الإعدادات والتدقيق.

أهم نتيجة تدقيق: التحويل من «مبيعات/مستندات تجارية» إلى **قوالب فواتير غير محاسبية** منفذ على السطح الحالي، لكن الأسماء الفيزيائية `sales_*` وثلاثة جداول legacy ما زالت في القاعدة. يجب تمييز النطاق المنطقي الحالي عن التوافق التاريخي، وألا تُوثق العروض أو الإيصالات أو الخطابات أو القيود أو التحصيل كوظائف متاحة.

توجد خمس نقاط لا يجوز تصنيفها «Implemented بالكامل»:

1. عقد دور `viewer` ملتبس؛ يمكن أن ترفعه عضوية مشروع بدور manager في السياسات الحالية.
2. إعدادات بداية الأسبوع والعطلة والمنطقة الزمنية مخزنة لكنها لا تتحكم بكل الحسابات/الجدول.
3. جاهزية الإنتاج مشروطة بماسح ملفات حقيقي وHTTPS ونسخ خارج المضيف وتمرين استعادة وتدقيق إتاحة يدوي.
4. قفل النسخة ليس موحداً على كل mutations، خصوصاً بعض الأرشفة/الاستعادة والعملاء.
5. اختبارات الإتاحة والمتصفح دليل smoke قوي، لكنها ليست شهادة WCAG ولا اختبار قارئ شاشة فعلي.

## 2. مقاييس الجرد المثبتة

| العنصر | العدد | ملاحظة |
|---|---:|---|
| المسارات المسجلة | 152 | 117 منتج، 30 مصادقة/Passkeys vendor، 5 framework/dev/health/storage |
| طرق المسارات | 65 GET/HEAD، 64 POST، 16 PUT، 3 PATCH، 3 DELETE، 1 PUT/PATCH | لقطة `artisan route:list --json` |
| Controllers | 31 | تشمل الإعدادات ومركز البيانات وPDF |
| Services | 31 | لا يوجد `app/Jobs` تطبيقي |
| Policies | 17 | المصدر الحاسم للصلاحية |
| Models | 25 | منها 3 نماذج legacy تجارية |
| Form Requests | 37 | تحقق/تفويض للعمليات الحساسة |
| React pages | 22 | صفحات فعلية، وصفحة المشروع متعددة التبويبات |
| React components | 56 | تشمل UI والبنية والنماذج |
| Migrations | 17 | كلها بحالة Ran في اللقطة |
| جداول فعلية | 40 | 27 عمل/دعم حالي، 4 هوية، 6 framework، 3 legacy؛ مع تداخل تصنيفي لـ`sales_documents` الحالي/الإرثي |
| Feature test files | 46 | PHPUnit/Pest |
| Unit test files | 6 | المجموع 52 ملف PHP |
| Browser scripts | 12 | `run-all.mjs` يشغّل 10 رحلات، وملفا runtime/orchestration |
| نتيجة PHP المستقلة | 256 اختباراً؛ 254 ناجحاً؛ 2 متروكان؛ 2724 assertion | 16.338 ثانية؛ المتروكان للتسجيل العام المعطل عمداً |
| أوامر Project Desk | 5 | نسخ، مزامنة تنبيهات، تنظيف أيتام، provision admin، ensure key |
| مهام مجدولة | 3 | النسخ والتنبيهات كل دقيقة؛ تنظيف الأيتام يومياً 03:30 Africa/Tripoli |
| Security subscriber events | 14 | دخول/خروج/فشل، 2FA، recovery codes، passkeys |

ملفات الجرد المصاحبة:

- `ROUTE_INVENTORY.csv`: كل المسارات الـ152 مع التصنيف والمجال والـmiddleware.
- `ENTITY_INVENTORY.csv`: كل الجداول الـ40 وتصنيف الحالي/الدعم/الإرث.
- `REQUIREMENT_COVERAGE.csv`: 54 مجموعة متطلبات وحالتها ودليل التنفيذ/الاختبار والتحذير التوثيقي.

## 3. الوحدات والشاشات الفعلية

| الوحدة/الشاشة | الحالة الفعلية | الوظائف والحدود |
|---|---|---|
| الصفحة العامة | Implemented | Welcome فقط؛ لا تسجيل عام |
| المصادقة | Implemented | دخول، خروج، نسيان/إعادة كلمة المرور، تحقق البريد، تأكيد كلمة المرور، 2FA، Passkeys |
| لوحة المتابعة | Implemented | KPIs، رسوم الحالة/الصحة، حمل العمل، مخاطر ومشكلات عالية، drill-down |
| الجدول الأسبوعي | Implemented with caps | اختيار أسبوع، صف لكل مشروع، الأحد–السبت، أشرطة مهام واجتماعات ممتدة ومقصوصة؛ 3 lanes وحدود تحميل/إخفاء |
| المشاريع | Implemented | قائمة/بحث/فلاتر/مقاييس/إنشاء/تحديث/أرشفة/استعادة/PDF |
| مساحة المشروع | Implemented | 11 تبويباً: overview، requirements، tasks، timeline، meetings، risks، issues، team، documents، client، activity |
| المهام | Implemented | قائمة وكانبان، بداية ونهاية إلزاميتان، مكلّف، حالات، متطلبات، سجل إسناد، archive/restore |
| العملاء | Implemented | CRUD، اتصالات، مشاريع، قيود أرشفة |
| الفريق | Implemented | عرض مقيد وإدارة داخلية للحسابات بواسطة Admin |
| المتطلبات | Implemented | CRUD، رمز، مالك، حالات، ربط مهام، lock/archive |
| كراسة المتطلبات | Implemented | كراسة واحدة، نسخ ملفات، حالة، current، archive/restore |
| الخط الزمني | Implemented | milestone/delivery/review/deadline/phase/event؛ الاجتماع نوع محجوز لخدمته |
| الاجتماعات | Implemented | وقت ومكان/URL ومنظم وجدول أعمال وحضور وربط timeline |
| المحاضر | Implemented | محضر واحد؛ ملخص وقرارات وإجراءات ومرفق آمن |
| تسجيل وسائط الاجتماع | Excluded | لا صوت/فيديو/streaming/transcription؛ «تسجيله في الجدول» يعني جدولة السجل |
| المخاطر | Implemented | احتمال/أثر 1–5، درجة، حالة، مالك، mitigation، due |
| المشكلات | Implemented | شدة وحالة ومالك وdue وresolution إلزامي للحل/الإغلاق |
| الوثائق | Implemented conditionally | ربط مشروع/مهمة/متطلب، وروابط متخصصة للكراسة والمحضر؛ safe فقط للتنزيل |
| البحث العام | Implemented limited | 5 نتائج/فئة؛ لا يبحث مباشرة في meetings/risks/issues/contacts |
| التنبيهات | Implemented limited | overdue/upcoming tasks وmeetings، تفضيلات، مزامنة دقيقة، فتح مع إعادة تحقق |
| قوالب الفواتير | Implemented non-accounting | إنشاء/تعديل/نسخ/أرشفة/استعادة/PDF، بنود وحساب نموذج؛ context اختياري |
| المحاسبة والمدفوعات | Excluded | لا ledger أو balances أو payments أو collection أو aging أو receipts |
| العروض/الإيصالات/الخطابات | Legacy hidden | جداول/نماذج تاريخية فقط؛ لا سطح حالي ولا تحويل مستندات |
| مركز البيانات | Implemented limited | CSV/XLSX export/template للعملاء/المشاريع/المهام؛ import للعملاء/المهام فقط |
| النسخ والاستعادة | Implemented local/operational | حزم `.pdesk`، تحقق، nonce، write fence، safety backup؛ التشغيل الخارجي بوابة |
| إعدادات النظام | Partial | الهوية والترقيم والحالات والتنبيهات والنسخ فعالة؛ التقويم/timezone غير موصلين بالكامل |
| الملف/الأمان الشخصي | Implemented | ملف وتفضيلات؛ كلمة مرور، 2FA، Passkeys |
| التدقيق | Implemented application-level | activity logs + request/correlation؛ ليس WORM/outbox |

## 4. توزيع مسارات المنتج

| المجال | العدد |
|---|---:|
| العملاء والاتصالات | 12 |
| مركز البيانات | 15 |
| التصدير المقيد | 1 |
| الملفات | 8 |
| قوالب الفواتير عبر URI إرثي `/sales` | 8 |
| المشكلات | 6 |
| الاجتماعات والمحاضر | 7 |
| التنبيهات | 1 |
| المشاريع | 7 |
| كراسة المتطلبات | 6 |
| المتطلبات | 6 |
| المخاطر | 6 |
| البحث | 1 |
| الإعدادات | 12 |
| الصفحة/لوحة المتابعة | 2 |
| المهام | 8 |
| الفريق | 5 |
| الخط الزمني | 6 |
| **المجموع** | **117** |

ملاحظة: هذه ليست REST API عامة. هي endpoints ويب تعتمد session وCSRF وInertia/JSON للمتصفح. لا يوجد token API أو webhook أو تكامل عام موثق.

## 5. الأدوار والصلاحيات — العقد الفعلي

### 5.1 الأدوار

- الأدوار العامة: `admin | project_manager | member | viewer`.
- أدوار عضوية المشروع: `manager | member | viewer` مع حالة عضوية.
- المستخدم المؤرشف أو غير النشط ممنوع عبر middleware/policies.
- Admin يرى ويدير كل المشاريع والعملاء والقوالب والإعدادات ومركز البيانات والفريق.
- Project Manager العام ينشئ مشاريع/عملاء/قوالب؛ رؤية القالب مقيدة بما أنشأه.
- مدير المشروع هو `manager_id` أو عضو نشط `project_role=manager`.
- عضو المشروع يمكنه الرؤية والرفع، ويمكن للمكلّف تحديث حالة مهمته.
- Viewer المحلي للمشروع للقراءة.
- قوالب الفواتير: Admin كل القوالب؛ PM قوالبه؛ Member/Viewer ممنوعان. عضوية المشروع لا تمنح وصول القالب.

### 5.2 فجوة P0: معنى Viewer

الوثائق التي تقول «global Viewer قراءة فقط دائماً» لا تطابق كل السياسات:

- `ProjectPolicy::update` لا يرفض `global_role=viewer` صراحة.
- إذا كان هذا المستخدم `manager_id` أو عضواً نشطاً بدور مشروع manager، فيمكنه إدارة المشروع وموارده التابعة.
- تحقق إسناد المهمة يعتمد دور المشروع manager/member ونشاط المستخدم، لا يمنع global viewer بحد ذاته.
- `ProjectPolicy::uploadFile` فقط يرفض global viewer صراحة، كما تمنعه سياسة قوالب الفواتير.

قرار مطلوب قبل اعتماد SRS:

1. إما أن يكون الدور العام مجرد افتراض وقد ترفعه عضوية المشروع؛ حينها يوثق هذا صراحة وتزال عبارة «قراءة فقط مطلقة».
2. أو أن يكون Viewer حاجزاً عاماً للقراءة فقط؛ حينها الحالة **Partial/defect** وتعدل السياسات والاختبارات.

لا يجوز اعتماد الخيار الثاني كـImplemented قبل تعديل التنفيذ.

## 6. الكيانات والبيانات

### 6.1 كيانات المجال الحالية

`users, clients, contacts, projects, project_members, requirements, requirement_books, requirement_book_versions, tasks, requirement_task, task_assignment_events, timeline_entries, meetings, meeting_attendees, meeting_minutes, risks, issues, file_objects, attachment_links, sales_documents, sales_line_items, document_sequences, data_jobs, import_errors, system_settings, workflow_statuses, activity_logs, notifications`.

### 6.2 الهوية ودعم Laravel

`sessions, password_reset_tokens, passkeys, cache, cache_locks, jobs, job_batches, failed_jobs, migrations`.

وجود `jobs/job_batches/failed_jobs` لا يعني وجود معالجة نطاقية queued؛ لا يوجد `app/Jobs` حالياً، وPDF/import/export تعمل تزامنياً.

### 6.3 بقايا تجارية غير حالية

`proposal_details, receipt_details, letter_details` ومعها احتمالية بيانات `sales_documents` بأنواع/حالات قديمة بعد ترقية قاعدة سابقة. هذه محفوظة للتوافق ولا تعرض في القوائم/البحث/PDF، ويجب ألا تظهر كمتطلبات حالية.

## 7. الخدمات والأوامر والأحداث

### 7.1 الخدمات الـ31

`ActivityLogger, ApplicationKeyEnsurer, CsvDataService, CsvExportService, CsvImportService, FileInventoryLock, MeetingService, NotificationCenterService, OrphanedFileGarbageCollector, PdfExportService, ProjectBackupBundleManager, ProjectFileScanner, ProjectFileService, ProjectMetrics, RequirementBookService, RequirementService, RestoreNonceManager, RestoreWriteFence, SalesCalculator, SalesDocumentLifecycle, SalesDocumentNumberGenerator, SalesDocumentService, SqliteBackupManager, SqliteBackupService, SystemSettingsService, TaskService, UserSessionSecurity, WeeklyScheduleBuilder, WorkflowStatusService, XlsxDataService, XlsxExportService`.

تحذيران للتوثيق:

- الاسم الفعلي هو `TaskService`؛ لا توجد `SaveTaskAction`.
- لا يوجد outbox أو domain event pipeline مخصص أو dispatch-after-commit عام. عمليات المجال تسجل `activity_logs` تزامنياً غالباً داخل المعاملة، والتنبيهات يعاد اشتقاقها بالمجدول.

### 7.2 أوامر التشغيل

| الأمر | الغرض |
|---|---|
| `project-desk:automatic-backup` | ينشئ النسخة عند حلول موعد الإعداد |
| `project-desk:sync-notifications` | يعيد اشتقاق تنبيهات المهام والاجتماعات |
| `project-desk:prune-orphaned-files` | يحذف أيتام الملفات بعد المهلة والقفل |
| `project-desk:provision-admin` | إنشاء أول مدير داخلي |
| `project-desk:ensure-app-key` | إنشاء APP_KEY عند غيابه |

### 7.3 الأحداث الملتقطة

`SecurityActivitySubscriber` يلتقط 14 حدث framework: نجاح/فشل الدخول والخروج، تمكين/تأكيد/تعطيل/تحدي/فشل/تحقق 2FA، إنشاء/استخدام recovery codes، وتسجيل/حذف/تحقق passkey. بقية «الأحداث» هي أسماء action داخل `activity_logs` وليست Event classes مستقلة.

## 8. السيناريوهات الحرجة وقبولها

| السيناريو | ما يجب إثباته | الحالة |
|---|---|---|
| مهمة متعددة الأيام | start/due إلزاميان، due≥start، وشريط يمتد ويقص عند حدود الأسبوع | Implemented + unit/feature |
| اجتماع في الجدول | إنشاء meeting وtimeline entry ذريعاً، end>start، حضور ومحضر | Implemented |
| كراسة متطلبات | ملف آمن، إصدار ورقم وحالة وcurrent واحد منطقياً | Implemented؛ current uniqueness منطق خدمة |
| تنزيل ملف | صلاحية المشروع + scan_status=safe + سجل نشاط | Implemented؛ يعتمد scanner |
| تعارض تعديل | رفض lock_version القديم | Implemented جزئياً وغير موحد لكل mutations |
| أرشفة عميل | منعها عند وجود مشروع نشط وتعطيل الاتصالات | Implemented |
| قالب فاتورة | invoice فقط، draft/archived، بند واحد، حساب decimal، PDF موسوم نموذج | Implemented non-accounting |
| استيراد | preview/checksum/errors ثم commit ذري | Implemented للعملاء/المهام فقط |
| استعادة نسخة | Admin + password + validation + nonce + phrase/hash + fence + safety backup + session invalidation | Implemented في التكامل المحلي؛ تمرين إنتاجي Planned |
| تنبيه | اشتقاق حسب الصلاحية والتفضيلات وحذف stale وإعادة تحقق عند الفتح | Implemented |
| تغيير حساس للمستخدم | كلمة مرور حديثة/حالية وإبطال جلسات وتصفير تحقق البريد عند تغييره | Implemented |
| فشل فحص ملف | production fail closed، وعدم تنزيل structurally_safe | Implemented؛ توافر الخدمة بوابة |

## 9. القيود التشغيلية وغير الوظيفية

- التقنية: Laravel 13.25.0، PHP 8.5.8، SQLite 3.53.2 في لقطة التدقيق.
- PHP CLI الحالي يفتقد `intl`؛ فشل `artisan db:show --counts` بعد عرض العدد. التوثيق يجب أن يجعل `intl` فحصاً إلزامياً.
- Node الافتراضي في shell هو 18.20.5 وpnpm 11.19.0، بينما Vite 8/التوثيق يحتاج Node أحدث (22.12+). استخدم runtime bundled موحد أو وثق مساره.
- ملف الإنتاج v1: مضيف Linux واحد، SQLite WAL، تخزين محلي خاص؛ لا نشر متعدد العقد ولا NFS/SMB للقاعدة.
- scheduler يجب تشغيله كل دقيقة، وإلا تتوقف التنبيهات والنسخ التلقائي والتنظيف.
- الملفات: افتراضياً 25MB، الأنواع pdf/docx/xlsx/csv/jpeg/png/webp، 20 رفعاً/دقيقة، 10GB/مشروع، 2GB/مستخدم-مشروع، 10000 ملف.
- الإنتاج يغلق الرفع دون malware scanner فعلي؛ Null scanner المحلي ليس حالة آمنة للتنزيل.
- البحث يطلب حرفين، حد 80 حرفاً و5 نتائج لكل فئة.
- صفحات المشروع تجزئ عادة 50، والنشاط 25.
- الجدول الأسبوعي يعرض مهاماً واجتماعات فقط، ويحمل بحد أقصى 50 من كل نوع/مشروع ثم يعرض المخفي.
- Security headers الحالية تشمل nosniff وDENY وreferrer/permissions وCOOP/CORP وHSTS عند production+HTTPS؛ لا CSP شامل للتطبيق. CSP sandbox يوجد لاستجابات التنزيل.
- `activity_logs` append-only باتفاق التطبيق لأنه لا توجد endpoint تعديل/حذف؛ ليس immutable/WORM بقيد قاعدة.
- لا multi-tenancy أو client portal أو native app أو AI أو timesheets أو dependency graph أو recurring tasks أو comments/mentions.
- لا تسجيل وسائط اجتماع أو transcription أو conferencing.
- لا REST API عامة أو webhooks.
- لا queue نطاقية؛ العمليات الثقيلة الحالية synchronous وذات caps.

## 10. نتيجة الاختبارات وحدود الدليل

### 10.1 PHP

تم تشغيل:

`php -d memory_limit=512M artisan test --compact --do-not-cache-result`

النتيجة: **256 tests، 254 passed، 2 skipped، 2724 assertions، 16.338s**. اختبارا التسجيل العام متروكان عمداً لأن self-registration معطل.

### 10.2 المتصفح والإتاحة

المستودع يحوي 12 ملف mjs؛ `run-all.mjs` يجمع 10 workflows. `RELEASE_READINESS.md` يسجل 10/10 سابقاً، لكن هذا التدقيق لم يعِد تشغيلها لأنها تغير بيانات التطبيق وتنتج screenshots.

فحص الإتاحة المخصص يغطي RTL/lang/main/H1/overflow/duplicate IDs/unnamed controls/alt/table labels وskip link وبعض keyboard behavior عبر 10 مسارات و5 أحجام. لا يجوز تحويل هذا إلى ادعاء «WCAG 2.2 AA»:

- لا axe أو suite معيارية شاملة.
- لا اختبار قارئ شاشة فعلي.
- لا actual browser zoom 200/400%؛ الموجود viewport simulation «zoom-equivalent».
- لا frontend unit/component runner مستقل.

الحالة الصحيحة: **Partial / verification gate**.

## 11. أعلى الفجوات والتناقضات للتجميد

| الأولوية | الموضوع | التصنيف الصحيح | الإجراء التوثيقي |
|---|---|---|---|
| P0 | global Viewer مقابل project manager membership | Partial / ambiguity | لا تدعِ read-only مطلقاً؛ سجل قرار صلاحيات واختباراته |
| P0 | قوالب الفواتير مقابل النظام المحاسبي | Implemented non-accounting + explicit exclusions | انْفِ ledger/payment/collection/receipt/proposal/letter، وافصل legacy tables |
| P0 | calendar/week_start/weekend_days | Partial not wired | اذكر أن الجدول ثابت الأحد وFri/Sat حالياً |
| P0 | general.timezone مقابل BUSINESS_TIMEZONE | Partial | لا تدعِ أن تغيير الإعداد يغير كل حسابات الوقت |
| P0 | production readiness | Planned/external gate | لا تصف النظام «معتمداً إنتاجياً» قبل scanner/HTTPS/off-host backup/restore drill |
| P1 | optimistic locking | Partial | لا تقل «كل تعديل/أرشفة» محمي؛ حدد الكيانات والعمليات |
| P1 | outbox/events/queues | Not implemented | احذف ادعاء outbox وdispatch-after-commit؛ queue tables scaffold |
| P1 | accessibility conformance | Partial/unverified | اذكر smoke فقط؛ قارئ الشاشة والتكبير الحقيقي بوابتان |
| P1 | toolchain reproducibility | Partial environment gap | ثبّت Node runtime وPHP extensions المطلوبة |
| P1 | file availability | Operational dependency | وضّح أن production يفشل مغلقاً دون scanner |
| P2 | search coverage | Implemented limited | لا تذكر meetings/risks/issues/contacts كفئات |
| P2 | imports | Implemented limited | clients/tasks فقط؛ projects export/template |
| P2 | weekly schedule caps | Implemented with caps | وثق 3 lanes والحدود والعناصر المخفية |
| P2 | audit immutability | Application-level only | لا تدعِ WORM/DB immutability |
| P2 | synchronous work | Implemented with caps | PDF/import/export ليست Jobs حالياً |
| P2 | stale naming | Legacy naming | URI `/sales` وSales* أسماء داخلية لا وحدة مبيعات |
| P2 | stale architecture claim | Documentation defect | استبدل `SaveTaskAction` بـ`TaskService` |

## 12. خصائص جزئية أو مؤجلة أو خارج النطاق

### Partial

- توصيل calendar/weekend/timezone.
- توحيد قفل النسخة على كل mutations.
- حسم أسبقية global role وproject role.
- إثبات الإتاحة المعيارية.
- تهيئة production scanner والنسخ الخارجية والتعافي والمراقبة.
- توحيد toolchain.

### Excluded / deferred

- أي محاسبة أو تحصيل أو مدفوعات أو أرصدة أو تقارير مالية.
- عروض وإيصالات وخطابات وتحويل مستندات.
- تسجيل وسائط الاجتماعات أو النسخ الصوتي.
- بوابة عميل أو حسابات للعملاء.
- SaaS multi-tenancy/subscriptions.
- native mobile apps.
- public API/webhooks.
- AI، timesheets، task dependencies، recurring tasks، comments/mentions.
- historical trend analytics دون event history مناسب.
- multi-node deployment في ملف v1.

## 13. قرار التغطية المقترح لـSRS

يمكن اعتماد الوحدات الحالية كـImplemented بشرط الاحتفاظ بالحدود السابقة، ووضع الحالات التالية صراحة:

- **Implemented non-accounting:** قوالب الفواتير.
- **Legacy hidden:** proposal/receipt/letter data and old sales document states.
- **Partial:** viewer authority contract، calendar/weekend/timezone، uniform optimistic locks، accessibility verification.
- **Operational/Planned:** scanner production integration، HTTPS/HSTS deployment، off-host backup replication، restore drill، screen-reader/zoom audit، production performance/pilot.
- **Excluded:** accounting، payment lifecycle، meeting media recording، client portal، public API، multi-tenancy والخصائص المؤجلة.

بهذا التصنيف تتوافق الكراسة مع التنفيذ ولا تحول scaffolding أو بيانات legacy أو اختبارات smoke إلى خصائص أو اعتمادات غير موجودة.
